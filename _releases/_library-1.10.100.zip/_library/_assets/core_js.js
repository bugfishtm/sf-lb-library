
	/*
		Example Core JS File
	*/